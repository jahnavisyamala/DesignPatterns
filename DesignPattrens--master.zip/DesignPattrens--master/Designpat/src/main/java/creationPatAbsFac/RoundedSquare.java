package creationPatAbsFac;

public class RoundedSquare implements Shape {
	  public String draw() {
	      return("Inside RoundedSquare::draw() method.");
	   }

}
