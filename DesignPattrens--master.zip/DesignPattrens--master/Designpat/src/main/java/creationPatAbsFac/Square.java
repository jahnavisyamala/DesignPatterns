package creationPatAbsFac;

public class Square implements Shape{
	 public String draw() {
	      return("Inside Square::draw() method.");
	   }
}
