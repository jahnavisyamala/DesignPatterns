package creationPatAbsFac;

public abstract class AbsFact {
	abstract Shape getShape(String shapeType);

}
