package creationPatAbsFac;
	public interface Shape {
		String draw();

}
