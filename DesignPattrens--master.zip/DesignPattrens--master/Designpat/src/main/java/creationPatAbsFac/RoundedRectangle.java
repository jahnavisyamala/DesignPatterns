package creationPatAbsFac;

public class RoundedRectangle  implements Shape {
	public String draw() {
	      return "Inside RoundedRectangle::draw() method.";
	   }
}
