package creationPatAbsFac;

public class Rectangle implements Shape {
	public String draw() {
	      return("Inside Rectangle::draw() method.");
	   }

}
