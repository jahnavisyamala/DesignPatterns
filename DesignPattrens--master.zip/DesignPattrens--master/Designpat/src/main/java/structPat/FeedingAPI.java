package structPat;

public interface FeedingAPI {
	public String feed(int timesADay, int amount, String typeOfFood);
}