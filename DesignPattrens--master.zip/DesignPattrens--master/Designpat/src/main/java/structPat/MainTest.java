package structPat;

import static org.junit.Assert.*;

import org.junit.Test;

public class MainTest {

	@Test
	public void testMain() {
		fail("Not yet implemented");
	}

}
