package behaviouralpat;
public interface Expression {
	
	public int interpret(InterpreterEngine engine);
}
