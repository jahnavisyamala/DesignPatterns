package behaviouralpat;

import static org.junit.Assert.*;

import org.junit.Test;

public class MultiplyExpressionTets {
	private InterpreterEngine engine;
	@Test
	public void testMultiplyExpression() {
		MultiplyExpression m=new MultiplyExpression("multiply 10 and 10");
	}

}