package behaviouralpatState;

public interface State {
	public String doAction(Conte conte);
}
