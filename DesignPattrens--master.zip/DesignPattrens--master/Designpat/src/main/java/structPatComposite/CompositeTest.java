package structPatComposite;

import static org.junit.Assert.*;

import org.junit.Test;

public class CompositeTest {

	@Test
	public void testMain() {
	}

}
